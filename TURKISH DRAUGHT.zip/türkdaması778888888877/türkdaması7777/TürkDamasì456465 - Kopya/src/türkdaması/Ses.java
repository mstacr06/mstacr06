/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package türkdaması;

import javax.sound.sampled.*;
import java.net.URL;

public class Ses {
    public static void sesCal(String dosyaAdi) {
        try {
            URL url = Ses.class.getResource("/sounds/" + dosyaAdi);
            if (url == null) {
                System.err.println("Ses dosyası bulunamadı: " + dosyaAdi);
                return;
            }

            AudioInputStream audioStream = AudioSystem.getAudioInputStream(url);
            Clip clip = AudioSystem.getClip();
            clip.open(audioStream);
            clip.start();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}



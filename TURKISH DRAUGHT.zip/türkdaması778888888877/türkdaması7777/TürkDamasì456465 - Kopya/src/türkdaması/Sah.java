/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package türkdaması;

/**
 *
 * @author erene
 */
    public class Sah extends Tas {

    public Sah(int x, int y, String renk) {
        super(x, y, renk);
    }

    @Override
    public void hareketEt(int yeniX, int yeniY) {
        // Şah için özel hareket kuralları
        System.out.println("Şah hareket ediyor...");
        super.hareketEt(yeniX, yeniY);
    }
}


package türkdaması;

import java.awt.*;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.ArrayList;
import java.util.List;
import javax.swing.*;

public class GamePanel extends JPanel implements MouseListener {

    private ArrayList<Tas> taslar = new ArrayList<>();
    private Tas secilenTas = null;
    private String sira = "beyaz";
    private Bot bot;

    
    private boolean botIleOyna;

    public GamePanel(boolean botIleOyna) {
        this.botIleOyna = botIleOyna;
        this.setPreferredSize(new Dimension(640, 640));
        this.setBackground(Color.LIGHT_GRAY);
        this.addMouseListener(this);
        if (botIleOyna) {
            bot = new Bot(this);
        }
        baslangicTaslariOlustur();
    }


    private void baslangicTaslariOlustur() {
        for (int row = 1; row < 3; row++) {
            for (int col = 0; col < 8; col++) {
                taslar.add(new Tas(col, row, "siyah"));
            }
        }
        for (int row = 5; row < 7; row++) {
            for (int col = 0; col < 8; col++) {
                taslar.add(new Tas(col, row, "beyaz"));
            }
        }
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        drawBoard(g);
        drawTaslar(g);
    }

    private void drawBoard(Graphics g) {
        int tileSize = 80;
        for (int row = 0; row < 8; row++) {
            for (int col = 0; col < 8; col++) {
                g.setColor((row + col) % 2 == 0 ? Color.WHITE : Color.DARK_GRAY);
                g.fillRect(col * tileSize, row * tileSize, tileSize, tileSize);
            }
        }
    }

    private void drawTaslar(Graphics g) {
        int tileSize = 80;
        for (Tas tas : taslar) {
            int x = tas.x * tileSize + 10;
            int y = tas.y * tileSize + 10;
            int size = 60;

            if (tas.renk.equals("siyah")) {
                g.setColor(Color.BLACK);
                g.fillOval(x, y, size, size);
            } else {
                g.setColor(Color.GRAY);
                g.fillOval(x + 3, y + 3, size, size);
                g.setColor(Color.WHITE);
                g.fillOval(x, y, size, size);
                g.setColor(Color.BLACK);
                g.drawOval(x, y, size, size);
            }

            if (tas == secilenTas) {
                g.setColor(Color.RED);
                g.drawOval(x - 2, y - 2, size + 4, size + 4);
            }

            if (tas.isKing) {
                g.setColor(Color.YELLOW);
                g.setFont(new Font("Arial", Font.BOLD, 20));
                g.drawString("Ş", x + 22, y + 38);
            }
        }
    }

    private Tas getTasAt(int x, int y) {
        for (Tas t : taslar) {
            if (t.x == x && t.y == y) return t;
        }
        return null;
    }

    private boolean isInsideBoard(int x, int y) {
        return x >= 0 && x < 8 && y >= 0 && y < 8;
    }

    public boolean tekrarYemeVarMi(Tas tas) {
        if (!tas.isKing) {
            int[][] directions = {{2, 0}, {-2, 0}, {0, 2}, {0, -2}};
            for (int[] d : directions) {
                int targetX = tas.x + d[0];
                int targetY = tas.y + d[1];
                if (isInsideBoard(targetX, targetY) && getTasAt(targetX, targetY) == null) {
                    int midX = tas.x + d[0] / 2;
                    int midY = tas.y + d[1] / 2;
                    Tas aradaki = getTasAt(midX, midY);
                    if (aradaki != null && !aradaki.renk.equals(tas.renk)) return true;
                }
            }
        } else {
            int[][] directions = {{1, 0}, {-1, 0}, {0, 1}, {0, -1}};
            for (int[] d : directions) {
                int x = tas.x + d[0], y = tas.y + d[1];
                boolean enemySeen = false;
                while (isInsideBoard(x, y)) {
                    Tas t = getTasAt(x, y);
                    if (t != null) {
                        if (t.renk.equals(tas.renk)) break;
                        if (!enemySeen) enemySeen = true;
                        else break;
                    } else if (enemySeen) {
                        return true;
                    }
                    x += d[0];
                    y += d[1];
                }
            }
        }
        return false;
    }

    private boolean zorunluYemeVar(String renk) {
        List<Tas> kopyaTaslar = new ArrayList<>(taslar);
        for (Tas t : kopyaTaslar) {
            if (t.renk.equals(renk) && tekrarYemeVarMi(t)) return true;
        }
        return false;
    }

    private boolean hamleGecerli(Tas tas, int hedefX, int hedefY) {
        if (!isInsideBoard(hedefX, hedefY)) return false;
        if (getTasAt(hedefX, hedefY) != null) return false;

        int dx = hedefX - tas.x;
        int dy = hedefY - tas.y;

        if (!tas.isKing) {
            if ((Math.abs(dx) == 1 && dy == 0) || (Math.abs(dy) == 1 && dx == 0)) {
                if (zorunluYemeVar(sira)) return false;
                if (tas.renk.equals("beyaz") && dy == -1) return true;
                if (tas.renk.equals("siyah") && dy == 1) return true;
                if (Math.abs(dx) == 1 && dy == 0) return true;
            } else if ((Math.abs(dx) == 2 && dy == 0) || (Math.abs(dy) == 2 && dx == 0)) {
                int mx = tas.x + dx / 2;
                int my = tas.y + dy / 2;
                Tas mid = getTasAt(mx, my);
                if (mid != null && !mid.renk.equals(tas.renk)) return true;
            }
        } else {
            if (dx == 0 || dy == 0) {
                int stepX = Integer.compare(dx, 0);
                int stepY = Integer.compare(dy, 0);
                int x = tas.x + stepX;
                int y = tas.y + stepY;
                int enemyCount = 0;

                while (x != hedefX || y != hedefY) {
                    Tas mid = getTasAt(x, y);
                    if (mid != null) {
                        if (mid.renk.equals(tas.renk)) return false;
                        enemyCount++;
                    }
                    x += stepX;
                    y += stepY;
                }
                return enemyCount <= 1;
            }
        }

        return false;
    }

    @Override
    public void mouseClicked(MouseEvent e) {
        int tileSize = 80;
        int col = e.getX() / tileSize;
        int row = e.getY() / tileSize;

        if (secilenTas == null) {
            Tas tiklanan = getTasAt(col, row);
            if (tiklanan != null && tiklanan.renk.equals(sira)) {
                secilenTas = tiklanan;
                repaint();
            }
        } else {
            if (hamleGecerli(secilenTas, col, row)) {
                hareketEt(secilenTas, col, row);
                if (sira.equals("siyah")) {
                    new Thread(() -> {
                        try {
                            Thread.sleep(500);
                        } catch (InterruptedException ex) {
                            ex.printStackTrace();
                        }
                        Ses.sesCal("hareket.wav");
                        bot.hamleYap();
                    }).start();
                }
                kontrolEtKazanan();
            } else {
                JOptionPane.showMessageDialog(this, "Geçersiz hamle! Zorunlu yeme olabilir.");
                secilenTas = null;
                repaint();
            }
        }
    }

    private void kontrolEtKazanan() {
        long beyaz = taslar.stream().filter(t -> t.renk.equals("beyaz")).count();
        long siyah = taslar.stream().filter(t -> t.renk.equals("siyah")).count();
        if (beyaz == 0) {
            JOptionPane.showMessageDialog(this, "Siyah kazandı!");
            new Thread(() -> Ses.sesCal("kazanma.wav")).start();
        } else if (siyah == 0) {
            JOptionPane.showMessageDialog(this, "Beyaz kazandı!");
            new Thread(() -> Ses.sesCal("kazanma.wav")).start();
        }
    }

    public void hareketEt(Tas tas, int yeniX, int yeniY) {
        int dx = yeniX - tas.x;
        int dy = yeniY - tas.y;
        boolean yemeYapildi = false;

        if (tas.isKing && (dx == 0 || dy == 0)) {
            int stepX = Integer.compare(dx, 0);
            int stepY = Integer.compare(dy, 0);
            int x = tas.x + stepX;
            int y = tas.y + stepY;
            
            while (x != yeniX || y != yeniY) {
                Tas aradaki = getTasAt(x, y);
                if (aradaki != null && !aradaki.renk.equals(tas.renk)) {
                    taslar.remove(aradaki);
                    yemeYapildi = true;
                    break;
                }
                x += stepX;
                y += stepY;
            }
        } else if (Math.abs(dx) == 2 || Math.abs(dy) == 2) {
            int midX = tas.x + dx / 2;
            int midY = tas.y + dy / 2;
            Tas aradaki = getTasAt(midX, midY);
             

            if (aradaki != null) {
                taslar.remove(aradaki);
                yemeYapildi = true;
            }
        }

        tas.x = yeniX;
        tas.y = yeniY;

        if ((tas.renk.equals("beyaz") && tas.y == 0) || (tas.renk.equals("siyah") && tas.y == 7)) {
            tas.isKing = true;
        }

        if (yemeYapildi && tekrarYemeVarMi(tas)) {
            secilenTas = tas;
        } else {
            secilenTas = null;
            setSira(tas.renk.equals("beyaz") ? "siyah" : "beyaz");
        }

        repaint();
    Ses.sesCal("hareket.wav");
    }

    public void setSira(String renk) {
        this.sira = renk;
    }

    public ArrayList<Tas> getTaslar() {
        return taslar;
    }

    public List<int[]> getGecerliHamleler(Tas tas) {
        List<int[]> hamleler = new ArrayList<>();
        for (int x = 0; x < 8; x++) {
            for (int y = 0; y < 8; y++) {
                if (hamleGecerli(tas, x, y)) {
                    hamleler.add(new int[]{x, y});
                }
            }
        }
        return hamleler;
    }

    public ArrayList<Tas> getBotTaslar() {
        ArrayList<Tas> botTaslar = new ArrayList<>();
        for (Tas t : taslar) {
            if (t.renk.equals("siyah")) {
                botTaslar.add(t);
            }
        }
        return botTaslar;
    }

    public void botHamleYap(Tas tas, int x, int y) {
        secilenTas = tas;
        mouseClicked(new MouseEvent(this, 0, 0, 0, x * 80 + 40, y * 80 + 40, 1, false));
    }

    public boolean gecerliHamleMi(Tas tas, int yeniX, int yeniY) {
        return hamleGecerli(tas, yeniX, yeniY);
    }

    public void setSecilenTas(Tas tas) {
        this.secilenTas = tas;
    }

    public Tas getYenilenTas(Tas from, int toX, int toY) {
        int dx = toX - from.x;
        int dy = toY - from.y;
        if (from.isKing) {
            int stepX = Integer.compare(dx, 0);
            int stepY = Integer.compare(dy, 0);
            int x = from.x + stepX;
            int y = from.y + stepY;
            while (x != toX || y != toY) {
                Tas aradaki = getTasAt(x, y);
                if (aradaki != null && !aradaki.renk.equals(from.renk)) {
                    return aradaki;
                }
                x += stepX;
                y += stepY;
            }
        } else if (Math.abs(dx) == 2 || Math.abs(dy) == 2) {
            return getTasAt(from.x + dx / 2, from.y + dy / 2);
        }
        return null;
    }

    @Override public void mousePressed(MouseEvent e) {}
    @Override public void mouseReleased(MouseEvent e) {}
    @Override public void mouseEntered(MouseEvent e) {}
    @Override public void mouseExited(MouseEvent e) {}

    public void animasyonBitti() {
        // Henüz kullanılmıyor
    }
}


package türkdaması;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;

/**
 *
 * @author erene
 */
public class Oyuncu {
    private Oyuncu beyazOyuncu = new Oyuncu("beyaz", 16);
    private Oyuncu siyahOyuncu = new Oyuncu("siyah", 16);


    private String renk;
    private int skor;
    private int tasSayisi;
    
private void drawTasSayilari(Graphics g) {
    g.setColor(Color.BLACK);
    g.setFont(new Font("Arial", Font.BOLD, 16));
    g.drawString("Beyaz taş: " + beyazOyuncu.getTasSayisi(), 660, 100);
    g.drawString("Siyah taş: " + siyahOyuncu.getTasSayisi(), 660, 140);
}

    public Oyuncu(String renk, int baslangicTasSayisi) {
        this.renk = renk;
        this.skor = 0;
        this.tasSayisi = baslangicTasSayisi;
    }

    public void puanEkle(int puan) {
        this.skor += puan;
    }

    public int getSkor() {
        return skor;
    }

    public String getRenk() {
        return renk;
    }

    public int getTasSayisi() {
        return tasSayisi;
    }

    public void tasAzalt() {
        if (tasSayisi > 0) {
            tasSayisi--;
        }
    }

    public void tasEkle() {
        tasSayisi++;
    }
}

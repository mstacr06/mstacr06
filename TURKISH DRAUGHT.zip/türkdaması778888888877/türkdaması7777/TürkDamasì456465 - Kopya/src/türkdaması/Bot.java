package türkdaması;

import java.util.*;

public class Bot {
    private GamePanel panel;                                                    //needtoaccessthegameboard//iuseittoget
    private Random random = new Random();                                       //thebothasmorethan//ithelpsrandomly                 
                                                                                //*************************
    public Bot(GamePanel panel) {                                               //igivethebotaccesstogamepanelsoitcan
        this.panel = panel;                                                     
    }                                                                           
                                                                                
    public void hamleYap() {                                                    //decideandplaysamove
        ArrayList<Tas> botTaslar = panel.getBotTaslar();                        //igetallthebotspiecesonlyblack
        List<Hamle> tumHamleler = new ArrayList<>();                            //icreatetosave
                                                                                
        for (Tas tas : botTaslar) {                                             //icheckedeverypiecethebothas
            List<int[]> hedefler = panel.getGecerliHamleler(tas);               //foreachpiecevalidmoveposition
            for (int[] hedef : hedefler) {                                      //icheckedeverypiece
                boolean yeme = panel.getYenilenTas(tas, hedef[0], hedef[1]) != null;//icheckifthemovewill
                                                                                    //eatanopponenspiece//ifitreturns
                boolean damaOlurMu = (tas.renk.equals("siyah") && hedef[1] == 7);//icheck
                int onem = yeme ? 2 : 0;                                        //2points:+1points
                if (damaOlurMu) onem += 1;                                      
                tumHamleler.add(new Hamle(tas, hedef[0], hedef[1], onem));      //isavethismovewithitsimp
                                                                                //intothelist

            }
        }

        if (tumHamleler.isEmpty()) return;                                      //ifnomoves,nothing

        
        int maxOnem = tumHamleler.stream().mapToInt(h -> h.onem).max().orElse(0);//ifindthehighestimp
        List<Hamle> secilebilir = new ArrayList<>();                            //formovesthathavethehighestimp
        for (Hamle h : tumHamleler) {                                           //iaddonlythemostimportant
            if (h.onem == maxOnem) secilebilir.add(h);                          //movesintothelist
        }

        Hamle secilen = secilebilir.get(random.nextInt(secilebilir.size()));    //oneofthebestimportantmvoesrandomly
        panel.botHamleYap(secilen.tas, secilen.x, secilen.y);                   //thebotmakesthemove

        // Zincirleme yeme kontrolü 
        new Thread(() -> {                                                      //icreatetocheckifthebotcaneatagain
            try {                                             
                Thread.sleep(500);  //0.5seconds                                //halfsecondforeachmove
                while (panel.tekrarYemeVarMi(secilen.tas)) {                    //iusealooptorepeateating
                    List<int[]> devamHamleler = panel.getGecerliHamleler(secilen.tas);//igetnextpossiblemovesforthesomepiece
                    boolean hamleYapildi = false;                               
                    for (int[] h : devamHamleler) {
                        if (panel.getYenilenTas(secilen.tas, h[0], h[1]) != null) { //ifthenextmovealsoeatsapiece
                            panel.botHamleYap(secilen.tas, h[0], h[1]);//botmakesanothermovetoeat
                            Thread.sleep(500);                                      //thismakesiteasiertoseemoves
                            hamleYapildi = true;
                            break;
                        }
                    }
                    if (!hamleYapildi) break;                                   //ifnomove stop
                }
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }).start();
    }

    private static class Hamle {
        Tas tas;
        int x, y;
        int onem;

        Hamle(Tas tas, int x, int y, int onem) {                                //helperclass
                                                                                //which
            this.tas = tas;                                                     //to
            this.x = x;                                                         //howimportantthatmoveis
            this.y = y;
            this.onem = onem;
        }
    }
}

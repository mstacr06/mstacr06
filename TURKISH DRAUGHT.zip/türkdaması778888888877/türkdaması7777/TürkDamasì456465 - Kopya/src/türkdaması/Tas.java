/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package türkdaması;

/**
 *
 * @author erene
 */
public class Tas {
    
  
    protected int x, y;
    protected String renk;
    boolean isKing = false;

    public Tas(int x, int y, String renk) {
        this.x = x;
        this.y = y;
        this.renk = renk;
    }

    public void hareketEt(int yeniX, int yeniY) {
        this.x = yeniX;
        this.y = yeniY;
    }
    
}

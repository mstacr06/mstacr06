
package türkdaması;

import javax.swing.JFrame;
import java.awt.Color;
import javax.swing.*;
import java.awt.*;

public class MainMenu extends JFrame {

    public MainMenu() {
        setTitle("🔥 Türk Daması");
        setSize(600, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null); 

        
        JPanel panel = new JPanel();
        panel.setBackground(new Color(10, 30, 100));
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));

        
        JLabel title = new JLabel("Türk Daması", SwingConstants.CENTER);
        title.setAlignmentX(Component.CENTER_ALIGNMENT);
        title.setFont(new Font("SansSerif", Font.BOLD, 36));
        title.setForeground(Color.WHITE);
        title.setBorder(BorderFactory.createEmptyBorder(40, 0, 40, 0));
        panel.add(title);

        
        JButton multiplayerButton = createStyledButton("👥 Multiplayer");
        JButton botButton = createStyledButton("🤖 Bot");

        
        multiplayerButton.addActionListener(e -> {
            new GameFrame(false); 
            dispose(); 
        });

        botButton.addActionListener(e -> {
            new GameFrame(true); 
            dispose();
        });

        
        panel.add(multiplayerButton);
        panel.add(Box.createVerticalStrut(200)); 
        panel.add(botButton);

        add(panel);
        setVisible(true);
    }

    private JButton createStyledButton(String text) {
        JButton button = new JButton(text);
        button.setAlignmentX(Component.CENTER_ALIGNMENT);
        button.setFont(new Font("SansSerif", Font.BOLD, 20));
        button.setForeground(Color.WHITE);
        button.setBackground(new Color(0, 130, 0));
        button.setFocusPainted(false);
        button.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));
        return button;
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new MainMenu());
    }
}
